package org.wso2.dataservice.validator.sample;

import org.wso2.carbon.dataservices.core.engine.ParamValue; 
import org.wso2.carbon.dataservices.core.validation.ValidationContext; 
import org.wso2.carbon.dataservices.core.validation.ValidationException; 
import org.wso2.carbon.dataservices.core.validation.Validator;

public class NumberValidator implements Validator { 

	public void validate(ValidationContext validationContext, String s, ParamValue paramValue) throws ValidationException {
		if (!paramValue.getScalarValue().startsWith("2")) {
			throw new ValidationException("Not starting with 2!!",s,paramValue);
		}
	}
}
