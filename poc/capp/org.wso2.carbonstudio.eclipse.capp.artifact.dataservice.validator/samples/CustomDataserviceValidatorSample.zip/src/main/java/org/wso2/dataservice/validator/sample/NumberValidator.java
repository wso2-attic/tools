package org.wso2.dataservice.validator.sample;

import org.wso2.carbon.dataservices.dispatch.ParamValue;
import org.wso2.carbon.dataservices.validation.ValidationContext;
import org.wso2.carbon.dataservices.validation.ValidationException;
import org.wso2.carbon.dataservices.validation.Validator;

public class NumberValidator implements Validator {

	public void validate(ValidationContext validationContext, String s, ParamValue paramValue) throws ValidationException {
		if (!paramValue.getScalarValue().startsWith("2")) {
			throw new ValidationException("Not starting with 2!!",s,paramValue);
		}
	}

}
