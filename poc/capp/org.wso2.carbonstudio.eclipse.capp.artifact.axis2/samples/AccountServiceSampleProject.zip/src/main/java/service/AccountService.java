package service;

import java.util.Hashtable;
import java.util.Random;

/**
 * 
 * @author kasun
 *         Modified by harshana
 * 
 *         This will store the accounts and a user can do operations on the
 *         account
 * 
 * @info debit : will increase the current amount credit: will decrease the
 *       current amount
 */
public class AccountService {

	// account no list of the customers
	 static Hashtable<Integer, Integer> accountStore = new Hashtable<Integer, Integer>();
	
	/**
	 * generates the random account no at registration
	 * 
	 * @return the random account number integer
	 */
	private int randomAccountGenerate() {
		Random randomGenerator = new Random();
		return randomGenerator.nextInt(1000);
	}
	
	/**
	 * create a new account and store
	 * 
	 * @return accountNo
	 * 
	 */
	public int createAccount() {

		int accountNo = 0;
		// Generate the random account no
		accountNo = randomAccountGenerate();
		// create the entry in the account store
		accountStore.put(accountNo, 0);
		return accountNo;
	}

	/**
	 * check whether the account is available
	 * 
	 * @param accountNo
	 * @return isAvailable
	 * 
	 */
	public boolean checkAccount(int accountNo) {
		if (accountStore.containsKey(accountNo)) {
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @param accountNo
	 * @return balance
	 * 
	 */
	public int checkAccountBalance(int accountNo) {
		if (checkAccount(accountNo)) {
			return accountStore.get(accountNo);
		}
		return 0;
	}



	/**
	 * decrease the balance by credit amount
	 * 
	 * @param accountNo
	 * @param amount
	 * @return success
	 * 
	 */
	public boolean creditAccount(int accountNo, int amount) {
		if (checkAccount(accountNo)) {
			accountStore.put(accountNo, (accountStore.remove(accountNo)+amount));
			return true;
		}
		return false;
	}

	/**
	 * increase the balance by the debit amount
	 * 
	 * @param accountNo
	 * @param amount
	 * @return Operation successfulness
	 * 
	 */
	public boolean debitAccount(int accountNo, int amount) {
		if (checkAccount(accountNo) && (accountStore.get(accountNo)>=amount)) {
			accountStore.put(accountNo, (accountStore.remove(accountNo)-amount));
			return true;
		}
		return false;
	}

	

}